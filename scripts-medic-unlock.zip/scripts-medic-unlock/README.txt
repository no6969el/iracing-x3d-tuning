MEDIC-UNLOCK EDITION  -  optional replacement scripts
============================================================
Two files. They replace the standard Pre-Race-Quiet.ps1 and
Post-Race-Restore.ps1 for people whose PC keeps switching
Windows Update back on mid-race.

DO YOU NEED THIS?
-----------------
Probably not. Try the standard scripts in ..\scripts\ first.

You need this edition ONLY if, after running the normal
Pre-Race-Quiet, the update services come back anyway - usually
about ten minutes in, with a stutter as they do.

To confirm before switching, run (elevated):

    ..\scripts\Trace-QuietReverts.ps1

If it reports something like

    WaaSMedicSvc: stopped, but could NOT disable (protected)

...then this edition is what you want. If it points at Group
Policy or an MDM profile instead, this will NOT help - a managed
machine will re-apply those settings regardless.

WHAT IS DIFFERENT
-----------------
Exactly one thing. On some Windows builds the registry key for
WaaSMedicSvc (Windows Update Medic) is owned by TrustedInstaller
and refuses to be disabled even when running as SYSTEM. Medic's
whole job is to detect a tampered update stack and repair it, so
while it runs it keeps undoing the quieting.

The standard edition stops there and tells you.
This edition takes ownership of that ONE key, disables the
service, and hands ownership straight back in the same run.

Everything else - services, tasks, Defender, snapshot, restore -
is identical.

HOW TO INSTALL
--------------
Copy both files over the ones in the scripts folder:

    scripts-medic-unlock\Pre-Race-Quiet.ps1     ->  scripts\
    scripts-medic-unlock\Post-Race-Restore.ps1  ->  scripts\

Keep a copy of the originals if you want to switch back. Nothing
else in the kit needs changing, and the menu picks these up
automatically.

HOW TO USE
----------
    .\Pre-Race-Quiet.ps1              before racing
    .\Post-Race-Restore.ps1           after racing  (REQUIRED)

First time, do this to prove the round trip works on your build:

    1. .\Pre-Race-Quiet.ps1 -Verify
       Waits 3 minutes and reports anything that came back.
       You want "nothing came back".

    2. .\Post-Race-Restore.ps1
       You want "permissions and owner (NT SERVICE\TrustedInstaller)
       restored".

Only once you have seen both should you rely on it for a race.

    .\Pre-Race-Quiet.ps1 -NoUnlock    behave like the standard edition

IS THIS SAFE?
-------------
It is more invasive than anything else in the kit, so judge for
yourself. What it actually does:

  * Reads the current owner and permissions BEFORE changing
    anything, and saves them to two places - the snapshot in
    C:\ProgramData\RaceQuiet\state.json and a separate
    WaaSMedicSvc.sddl file next to it.
  * Takes ownership, grants Administrators write access, sets the
    service to Disabled.
  * Hands the original permissions back immediately, in the same
    run. The key is in a modified state for seconds, not for the
    length of your session.
  * Post-Race-Restore verifies the owner and permissions are back,
    and REFUSES to delete the snapshot while any key is still
    unrestored - so a half-finished restore cannot be silently
    forgotten.
  * If it ever fails to restore, it prints the exact commands to
    put it right, with your own saved descriptor filled in.

Nothing is deleted, nothing is permanent, and the service ends up
back exactly as Windows had it.

IF SOMETHING GOES WRONG
-----------------------
Run Post-Race-Restore.ps1 again, elevated. It reads the .sddl
file even if the snapshot is gone.

Still stuck? The saved descriptor is in
C:\ProgramData\RaceQuiet\WaaSMedicSvc.sddl - line 1 is the owner,
line 2 is the security descriptor. Do not delete that file until
the restore has confirmed success.

WHY THIS IS NOT THE DEFAULT
---------------------------
Most people do not need it - the standard scripts hold fine on the
majority of machines. A tool that routinely reassigns ownership of
system registry keys is a different proposition from one that
flips documented settings, so it is kept opt-in and behind a
diagnostic that proves it is necessary.
